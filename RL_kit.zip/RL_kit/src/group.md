Grupo 1
Nome - Cartão - Turma
Artur Ruiz de Souza - 00334954 - B
Izaias Saturnino de Lima Neto - 00326872 - B
Vinicius Matte Medeiros - 00330087 - B

Referências:
Algoritmos de Aprendizagem por reforço slides (igual vídeo)